<?php
/**
 * Created by PhpStorm.
 * User: heixiake
 * Date: 2018/5/15
 * Time: 2:15 PM
 */
echo "this is a php\n";

for ($i=0; $i<1000; $i++){
    $emails[]="zly".$i."@126.com";
}
var_dump($emails);