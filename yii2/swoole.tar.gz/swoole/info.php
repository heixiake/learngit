<?php

phpinfo();
?>
