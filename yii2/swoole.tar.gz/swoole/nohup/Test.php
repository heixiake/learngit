<?php
/**
 * Created by PhpStorm.
 * User: heixiake
 * Date: 2018/5/24
 * Time: 9:26 AM
 */


class Test
{
    public function run($data)
    {
        echo $data;
    }
}