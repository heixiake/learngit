<?php
/**
 * Created by PhpStorm.
 * User: heixiake
 * Date: 2018/5/25
 * Time: 12:12 PM
 */

echo __FILE__."\n";

echo "yii2 swoole index\n";